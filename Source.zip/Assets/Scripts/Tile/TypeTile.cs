﻿using System;

public enum TypeTile
{
    None = 0,
    Plains = 1,
    Forest = 2,
    Moutain = 4,
    CopperMoutain = 8,
    IronMoutain = 16,
    CoalMoutain = 32,
    Ocean = 64,
}